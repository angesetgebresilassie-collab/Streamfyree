package com.streamfyree.app.ui

import android.webkit.WebSettings
import android.webkit.WebView
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.QueueMusic
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.Headphones
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.RemoveCircleOutline
import androidx.compose.material.icons.filled.AddCircleOutline
import androidx.compose.material.icons.filled.Shuffle
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material.icons.filled.Repeat
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Group
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.*
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.palette.graphics.Palette
import coil3.request.ImageRequest
import coil3.toBitmap
import coil3.compose.AsyncImage
import com.streamfyree.app.*

// ---- Palette: warm brown, Spotify-shaped layout ----
private val BG = Color(0xFF0A0705)
private val BG2 = Color(0xFF17100B)
private val WARM_WHITE = Color(0xFFF3EAE1)
private val MUTED = Color(0xFFAD9F94)
private val ACCENT = Color(0xFFE0A662)
private val ACCENT2 = Color(0xFF8C5A2B)
private val CARD = Color(0xFF1C1611)
private val CARD_RAISED = Color(0xFF241B14)
private val CHIP_OFF = Color(0xFF211A14)
private val SHADOW = Color(0xFF000000)
private val HAIRLINE = Color.White.copy(alpha = .07f)

private val R_XS = RoundedCornerShape(4.dp)
private val R_SM = RoundedCornerShape(6.dp)
private val R_MD = RoundedCornerShape(8.dp)
private val R_PILL = RoundedCornerShape(50)

// Reusable card elevation: a soft, low-contrast drop shadow instead of a flat
// alpha border. Reads as depth rather than a "wireframe with a stroke".
private fun Modifier.elevatedCard(shape: Shape, elevation: androidx.compose.ui.unit.Dp = 8.dp) = this.shadow(
    elevation = elevation,
    shape = shape,
    ambientColor = SHADOW.copy(alpha = .5f),
    spotColor = SHADOW.copy(alpha = .6f)
)

private data class GenreTile(val label: String, val gradient: List<Color>)

private val genreTiles = listOf(
    GenreTile("Pop", listOf(Color(0xFFC1683A), Color(0xFF8A3F1F))),
    GenreTile("Hip-Hop", listOf(Color(0xFF7A5233), Color(0xFF3E2C1B))),
    GenreTile("R&B", listOf(Color(0xFFD4913F), Color(0xFF934F1E))),
    GenreTile("Rock", listOf(Color(0xFF66503C), Color(0xFF362A1E))),
    GenreTile("Chill", listOf(Color(0xFF9A6A3F), Color(0xFF54371F))),
    GenreTile("Focus", listOf(Color(0xFF7D6038), Color(0xFF41311B))),
    GenreTile("Party", listOf(Color(0xFFCB8636), Color(0xFF8F4E1B))),
    GenreTile("Workout", listOf(Color(0xFF8A5F35), Color(0xFF48311B)))
)

private fun formatTime(ms: Long): String {
    val totalSeconds = (ms / 1000).coerceAtLeast(0)
    val m = totalSeconds / 60
    val s = totalSeconds % 60
    return String.format("%d:%02d", m, s)
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StreamfyreeScreen(vm: MusicViewModel) {
    val state by vm.state.collectAsState()
    val mode by vm.mode.collectAsState()
    val current by vm.current.collectAsState()
    val queue by vm.queue.collectAsState()
    val library by vm.library.collectAsState()
    val history by vm.history.collectAsState()
    val discoverTracks by vm.discoverTracks.collectAsState()
    val playlists by vm.playlists.collectAsState()
    val isPlaying by vm.isPlaying.collectAsState()
    val progress by vm.progress.collectAsState()

    var query by remember { mutableStateOf("") }
    var tab by remember { mutableIntStateOf(0) }
    var homeFilter by remember { mutableIntStateOf(0) }
    var showPlayer by remember { mutableStateOf(false) }
    var showQueue by remember { mutableStateOf(false) }

    LaunchedEffect(isPlaying, current?.id) {
        while (isPlaying) {
            vm.refreshProgress()
            kotlinx.coroutines.delay(500)
        }
        vm.refreshProgress()
    }

    if (showPlayer && current != null) {
        ModalBottomSheet(
            onDismissRequest = { showPlayer = false },
            containerColor = BG,
            tonalElevation = 0.dp
        ) {
            val track = current!!
            FullPlayer(
                track = track,
                isPlaying = isPlaying,
                mode = mode,
                progress = progress,
                saved = vm.isSaved(track),
                onToggle = vm::togglePlayPause,
                onPrevious = vm::previous,
                onNext = vm::next,
                onSeek = vm::seekTo,
                onSave = { if (vm.isSaved(track)) vm.unsaveTrack(track) else vm.saveTrack(track) },
                onQueue = { showPlayer = false; showQueue = true },
                onClose = { showPlayer = false }
            )
        }
    }

    if (showQueue) {
        ModalBottomSheet(
            onDismissRequest = { showQueue = false },
            containerColor = BG,
            tonalElevation = 0.dp
        ) {
            QueueSheet(
                queue = queue,
                currentId = current?.id,
                onPlay = { track -> showPlayer = true; vm.play(track) },
                onRemove = vm::removeFromQueue,
                onClear = vm::clearQueue
            )
        }
    }

    val bottomPad = if (current != null) 158.dp else 96.dp

    Box(
        Modifier.fillMaxSize().background(
            Brush.verticalGradient(listOf(BG2, BG, BG), endY = 900f)
        )
    ) {
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(16.dp, 12.dp, 16.dp, bottomPad),
            verticalArrangement = Arrangement.spacedBy(24.dp)
        ) {
            item {
                TopIconBar(
                    onHome = { tab = 0 },
                    onSearch = { tab = 1 },
                    onLibrary = { tab = 2 }
                )
            }

            when (tab) {
                0 -> {
                    item { ChipRow(homeFilter) { homeFilter = it } }

                    if (homeFilter != 1) {
                        val quickPicks = (library.saved + history).distinctBy { it.id }.take(8)
                        item {
                            QuickAccessGrid(
                                playlists = playlists,
                                tracks = quickPicks,
                                onOpenLibrary = { tab = 2 },
                                onPlayPlaylist = { pl -> showPlayer = true; vm.playPlaylist(pl) },
                                onPlayTrack = { track -> showPlayer = true; vm.play(track) }
                            )
                        }
                    }

                    if (homeFilter != 2) {
                        current?.let { track ->
                            item {
                                ContinueListeningCard(track, isPlaying, { showPlayer = true }, vm::togglePlayPause)
                            }
                        }
                    }

                    item {
                        SearchBar(
                            value = query,
                            onValueChange = { query = it },
                            onSearch = { tab = 1; vm.search(query) }
                        )
                    }
                    if (homeFilter != 2) item { PlaybackModes(mode, vm::setMode) }
                    state.error?.let { message -> item { ErrorPill(message) } }

                    if (homeFilter != 2 && discoverTracks.isNotEmpty()) {
                        item {
                            SectionHeader(
                                "Fresh Mix",
                                "A randomized feed of real songs, refreshed each time you open the app"
                            )
                        }
                        items(discoverTracks, key = { "discover-" + it.id }) { track ->
                            SongCard(
                                track = track,
                                saved = vm.isSaved(track),
                                onPlay = { showPlayer = true; vm.play(track) },
                                onQueue = { vm.enqueue(track) },
                                onSave = {
                                    if (vm.isSaved(track)) vm.unsaveTrack(track)
                                    else vm.saveTrack(track)
                                }
                            )
                        }
                    }

                    if (homeFilter != 2 && state.tracks.isNotEmpty()) {
                        item { SectionHeader("Trending Now", "Real songs from your latest search") }
                        items(state.tracks.take(8), key = { "trend-" + it.id }) { track ->
                            SongCard(
                                track = track,
                                rank = state.tracks.indexOf(track) + 1,
                                saved = vm.isSaved(track),
                                onPlay = { showPlayer = true; vm.play(track) },
                                onQueue = { vm.enqueue(track) },
                                onSave = { if (vm.isSaved(track)) vm.unsaveTrack(track) else vm.saveTrack(track) }
                            )
                        }
                    }

                    if (homeFilter != 2 && history.isNotEmpty()) {
                        item { SectionHeader("Recently Played", "Pick up where you left off") }
                        item {
                            LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                                items(history.take(8), key = { "hist-" + it.id }) { track ->
                                    HistoryTile(track) { showPlayer = true; vm.play(track) }
                                }
                            }
                        }
                    }

                    if (homeFilter != 1 && playlists.isNotEmpty()) {
                        item { SectionHeader("Your Playlists", "Collections built from your music") }
                        item {
                            LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                                items(playlists, key = { "pl-" + it.id }) { pl ->
                                    PlaylistCard(pl) { showPlayer = true; vm.playPlaylist(pl) }
                                }
                            }
                        }
                    }
                }

                1 -> {
                    item { SearchBar(query, { query = it }, { vm.search(query) }, "Search songs, artists, albums…") }
                    item { PlaybackModes(mode, vm::setMode) }
                    state.error?.let { message -> item { ErrorPill(message) } }
                    if (state.loading) {
                        item {
                            LinearProgressIndicator(
                                Modifier.fillMaxWidth().clip(RoundedCornerShape(8.dp)),
                                color = ACCENT,
                                trackColor = Color.White.copy(alpha = .1f)
                            )
                        }
                    }
                    if (!state.loading && state.tracks.isEmpty() && query.isBlank()) {
                        item { SectionHeader("Browse all", "Jump into a search") }
                        item { BrowseGrid { picked -> query = picked; vm.search(picked) } }
                    } else if (!state.loading && state.tracks.isEmpty()) {
                        item { EmptyState(Icons.Default.Search, "No results", "Try a different search term.") }
                    }
                    if (state.tracks.isNotEmpty()) {
                        item { SectionHeader("Search Results", "Artwork and metadata from iTunes; lyric candidates are searched online") }
                        items(state.tracks, key = { "search-" + it.id }) { track ->
                            SongCard(
                                track = track,
                                saved = vm.isSaved(track),
                                onPlay = { showPlayer = true; vm.play(track) },
                                onQueue = { vm.enqueue(track) },
                                onSave = { if (vm.isSaved(track)) vm.unsaveTrack(track) else vm.saveTrack(track) }
                            )
                        }
                    }
                }

                2 -> {
                    item { SectionHeader("Your Library", "Saved music") }
                    if (library.saved.isEmpty()) {
                        item { EmptyState(Icons.Default.FavoriteBorder, "Your library is empty", "Save a real song and it will appear here.") }
                    } else {
                        items(library.saved, key = { "lib-" + it.id }) { track ->
                            SongCard(
                                track = track,
                                saved = true,
                                onPlay = { showPlayer = true; vm.play(track) },
                                onQueue = { vm.enqueue(track) },
                                onSave = { vm.unsaveTrack(track) }
                            )
                        }
                    }
                }

                3 -> {
                    item { SectionHeader("Queue", queue.size.toString() + " songs") }
                    if (queue.isEmpty()) {
                        item { EmptyState(Icons.Default.QueueMusic, "Nothing queued", "Add a song from a result.") }
                    } else {
                        item {
                            TextButton(onClick = vm::clearQueue) {
                                Text("Clear queue", color = ACCENT)
                            }
                        }
                        items(queue, key = { "queue-" + it.id }) { track ->
                            SongCard(
                                track = track,
                                saved = vm.isSaved(track),
                                onPlay = { showPlayer = true; vm.play(track) },
                                onQueue = { vm.removeFromQueue(track) },
                                onSave = { if (vm.isSaved(track)) vm.unsaveTrack(track) else vm.saveTrack(track) },
                                removeFromQueue = true
                            )
                        }
                    }
                }
            }
        }

        Column(Modifier.align(Alignment.BottomCenter).fillMaxWidth()) {
            current?.let { track ->
                MiniPlayerBar(
                    track = track,
                    isPlaying = isPlaying,
                    progress = progress,
                    onOpen = { showPlayer = true },
                    onToggle = vm::togglePlayPause,
                    onNext = vm::next
                )
            }
            BottomNavBar(tab) { tab = it }
        }
    }
}

@Composable
private fun BottomNavBar(tab: Int, onTab: (Int) -> Unit) {
    Surface(
        modifier = Modifier.fillMaxWidth().shadow(elevation = 16.dp, ambientColor = SHADOW, spotColor = SHADOW),
        color = Color(0xFF120D0A).copy(alpha = .98f)
    ) {
        Column {
            Box(Modifier.fillMaxWidth().height(1.dp).background(HAIRLINE))
            Row(
                Modifier.fillMaxWidth().padding(vertical = 10.dp, horizontal = 10.dp),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                NavItem(tab == 0, { onTab(0) }, Icons.Default.Home, Icons.Default.Home, "Home")
                NavItem(tab == 1, { onTab(1) }, Icons.Default.Search, Icons.Default.Search, "Search")
                NavItem(tab == 2, { onTab(2) }, Icons.Default.Favorite, Icons.Default.FavoriteBorder, "Library")
                NavItem(tab == 3, { onTab(3) }, Icons.Default.QueueMusic, Icons.Default.QueueMusic, "Queue")
            }
        }
    }
}

@Composable
private fun NavItem(
    selected: Boolean,
    onClick: () -> Unit,
    selectedIcon: androidx.compose.ui.graphics.vector.ImageVector,
    unselectedIcon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String
) {
    Surface(
        modifier = Modifier.clip(RoundedCornerShape(16.dp)).clickable(onClick = onClick),
        shape = RoundedCornerShape(16.dp),
        color = if (selected) ACCENT.copy(alpha = .16f) else Color.Transparent
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                if (selected) selectedIcon else unselectedIcon,
                contentDescription = label,
                tint = if (selected) ACCENT else MUTED,
                modifier = Modifier.size(21.dp)
            )
            if (selected) {
                Spacer(Modifier.width(7.dp))
                Text(label, color = ACCENT, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
private fun MiniPlayerBar(
    track: Track,
    isPlaying: Boolean,
    progress: PlaybackProgress,
    onOpen: () -> Unit,
    onToggle: () -> Unit,
    onNext: () -> Unit
) {
    var tint by remember(track.artwork) { mutableStateOf(ACCENT) }
    val shape = RoundedCornerShape(topStart = 18.dp, topEnd = 18.dp)
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 10.dp)
            .shadow(elevation = 14.dp, shape = shape, ambientColor = SHADOW.copy(alpha = .6f), spotColor = SHADOW.copy(alpha = .7f))
            .clip(shape)
            .clickable(onClick = onOpen),
        shape = shape,
        color = Color(0xFF1B140F).copy(alpha = .98f)
    ) {
        Column {
            if (progress.durationMs > 0) {
                Box(Modifier.fillMaxWidth().height(2.dp).background(Color.White.copy(alpha = .08f))) {
                    Box(
                        Modifier
                            .fillMaxWidth((progress.positionMs.toFloat() / progress.durationMs.toFloat()).coerceIn(0f, 1f))
                            .height(2.dp)
                            .background(Brush.horizontalGradient(listOf(ACCENT2, ACCENT)))
                    )
                }
            }
            Row(Modifier.padding(start = 10.dp, end = 4.dp, top = 8.dp, bottom = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                ArtworkImage(track, tint, { tint = it }, Modifier.size(44.dp).clip(RoundedCornerShape(11.dp)))
                Spacer(Modifier.width(11.dp))
                Column(Modifier.weight(1f)) {
                    Text(track.title, color = WARM_WHITE, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
                    Text(track.artist, color = MUTED, fontSize = 11.sp, maxLines = 1)
                }
                IconButton(onClick = onToggle) {
                    Icon(if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow, "Play or pause", tint = WARM_WHITE)
                }
                IconButton(onClick = onNext) {
                    Icon(Icons.Default.SkipNext, "Next", tint = WARM_WHITE)
                }
            }
        }
    }
}

@Composable
private fun FrostedPanel(
    shape: Shape,
    modifier: Modifier = Modifier,
    accent: Color = ACCENT,
    content: @Composable BoxScope.() -> Unit
) {
    Box(modifier.elevatedCard(shape, 6.dp).clip(shape)) {
        Box(
            Modifier
                .matchParentSize()
                .blur(30.dp)
                .background(Brush.linearGradient(listOf(accent.copy(alpha = .26f), ACCENT2.copy(alpha = .12f), Color.Transparent)))
        )
        Box(Modifier.matchParentSize().background(CARD))
        Box(Modifier.matchParentSize().border(1.dp, Color.White.copy(alpha = .08f), shape))
        content()
    }
}

@Composable
private fun TopIconBar(onHome: () -> Unit, onSearch: () -> Unit, onLibrary: () -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        RoundIconButton(Icons.Default.Home, "Home", onHome)
        Spacer(Modifier.width(10.dp))
        RoundIconButton(Icons.Default.Search, "Search", onSearch)
        Spacer(Modifier.weight(1f))
        RoundIconButton(Icons.Default.Notifications, "Notifications") {}
        Spacer(Modifier.width(10.dp))
        RoundIconButton(Icons.Default.Group, "Friends") {}
        Spacer(Modifier.width(10.dp))
        Surface(
            modifier = Modifier.size(38.dp).clip(CircleShape).clickable(onClick = onLibrary),
            shape = CircleShape,
            color = ACCENT.copy(alpha = .22f)
        ) {
            Box(contentAlignment = Alignment.Center) {
                Icon(Icons.Default.Person, null, tint = ACCENT, modifier = Modifier.size(20.dp))
            }
        }
    }
}

@Composable
private fun RoundIconButton(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, onClick: () -> Unit) {
    Surface(
        modifier = Modifier.size(38.dp).clip(CircleShape).clickable(onClick = onClick),
        shape = CircleShape,
        color = CARD_RAISED.copy(alpha = .85f)
    ) {
        Box(contentAlignment = Alignment.Center) {
            Icon(icon, label, tint = WARM_WHITE, modifier = Modifier.size(19.dp))
        }
    }
}

@Composable
private fun ChipRow(selected: Int, onSelect: (Int) -> Unit) {
    val chips = listOf("All", "Music", "Playlists")
    Row(
        Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        chips.forEachIndexed { i, label ->
            val chipShape = RoundedCornerShape(16.dp)
            Surface(
                Modifier
                    .let { if (selected == i) it.elevatedCard(chipShape, 4.dp) else it }
                    .clip(chipShape)
                    .clickable { onSelect(i) },
                chipShape,
                color = if (selected == i) ACCENT else CARD_RAISED.copy(alpha = .7f)
            ) {
                Text(
                    label,
                    Modifier.padding(horizontal = 14.dp, vertical = 7.dp),
                    color = if (selected == i) BG else WARM_WHITE,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold
                )
            }
        }
    }
}

@Composable
private fun ContinueListeningCard(track: Track, isPlaying: Boolean, onOpen: () -> Unit, onToggle: () -> Unit) {
    var tint by remember(track.artwork) { mutableStateOf(ACCENT) }
    FrostedPanel(RoundedCornerShape(18.dp), Modifier.fillMaxWidth().clickable(onClick = onOpen), accent = tint) {
        Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            ArtworkImage(track, tint, { tint = it }, Modifier.size(52.dp).clip(RoundedCornerShape(12.dp)))
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text("CONTINUE LISTENING", color = ACCENT, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                Text(track.title, color = WARM_WHITE, fontSize = 15.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                Text(track.artist, color = MUTED, fontSize = 12.sp, maxLines = 1)
            }
            FilledIconButton(
                onClick = onToggle,
                modifier = Modifier.size(42.dp),
                colors = IconButtonDefaults.filledIconButtonColors(containerColor = ACCENT, contentColor = BG)
            ) {
                Icon(if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow, "Play")
            }
        }
    }
}

private data class QuickEntry(
    val label: String,
    val artwork: String?,
    val isLiked: Boolean,
    val onClick: () -> Unit
)

@Composable
private fun QuickAccessGrid(
    playlists: List<Playlist>,
    tracks: List<Track>,
    onOpenLibrary: () -> Unit,
    onPlayPlaylist: (Playlist) -> Unit,
    onPlayTrack: (Track) -> Unit
) {
    val liked = playlists.firstOrNull { it.id == "liked" }
    val otherPlaylists = playlists.filterNot { it.id == "liked" }

    val entries = remember(playlists, tracks) {
        val list = mutableListOf<QuickEntry>()
        list += QuickEntry(
            "Liked Songs",
            liked?.artwork,
            true,
            if (liked != null) ({ onPlayPlaylist(liked) }) else onOpenLibrary
        )
        otherPlaylists.forEach { pl ->
            if (list.size < 8) list += QuickEntry(pl.title, pl.artwork, false) { onPlayPlaylist(pl) }
        }
        tracks.forEach { t ->
            if (list.size < 8) list += QuickEntry(t.title, t.artwork, false) { onPlayTrack(t) }
        }
        list
    }

    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        entries.chunked(2).forEach { row ->
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                row.forEach { entry ->
                    QuickAccessTile(entry.label, entry.artwork, entry.isLiked, Modifier.weight(1f), entry.onClick)
                }
                if (row.size == 1) Spacer(Modifier.weight(1f))
            }
        }
    }
}

@Composable
private fun QuickAccessTile(label: String, artwork: String?, isLiked: Boolean, modifier: Modifier, onClick: () -> Unit) {
    val shape = RoundedCornerShape(6.dp)
    Surface(
        modifier = modifier.height(56.dp).elevatedCard(shape, 3.dp).clip(shape).clickable(onClick = onClick),
        shape = shape,
        color = CARD_RAISED.copy(alpha = .9f)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            if (isLiked) {
                Box(
                    Modifier.size(56.dp).background(Brush.linearGradient(listOf(ACCENT2, ACCENT))),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Default.Favorite, null, tint = WARM_WHITE, modifier = Modifier.size(24.dp))
                }
            } else if (!artwork.isNullOrBlank()) {
                var tint by remember(artwork) { mutableStateOf(ACCENT) }
                ArtworkImageUrl(artwork, label, tint, { tint = it }, Modifier.size(56.dp))
            } else {
                Box(Modifier.size(56.dp).background(CARD))
            }
            Text(
                label,
                Modifier.padding(horizontal = 10.dp).weight(1f),
                color = WARM_WHITE,
                fontSize = 13.sp,
                fontWeight = FontWeight.SemiBold,
                maxLines = 2
            )
        }
    }
}

@Composable
private fun PlaylistCard(playlist: Playlist, onClick: () -> Unit) {
    var tint by remember(playlist.artwork) { mutableStateOf(ACCENT) }
    GlassCard(RoundedCornerShape(20.dp), Modifier.width(150.dp).clickable(onClick = onClick)) {
        Column {
            Box(Modifier.fillMaxWidth().aspectRatio(1f)) {
                if (!playlist.artwork.isNullOrBlank()) {
                    ArtworkImageUrl(
                        playlist.artwork, playlist.title, tint, { tint = it },
                        Modifier.fillMaxSize().clip(RoundedCornerShape(18.dp))
                    )
                } else {
                    Box(
                        Modifier.fillMaxSize().clip(RoundedCornerShape(18.dp))
                            .background(Brush.linearGradient(listOf(ACCENT, ACCENT2)))
                    )
                }
                Surface(
                    Modifier.align(Alignment.BottomStart).padding(8.dp),
                    shape = RoundedCornerShape(6.dp),
                    color = Color.Black.copy(alpha = .55f)
                ) {
                    Text(
                        "PLAYLIST",
                        Modifier.padding(horizontal = 6.dp, vertical = 3.dp),
                        color = WARM_WHITE,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = .8.sp
                    )
                }
            }
            Column(Modifier.padding(10.dp)) {
                Text(playlist.title, color = WARM_WHITE, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
                Text(playlist.subtitle, color = MUTED, fontSize = 11.sp, maxLines = 1)
            }
        }
    }
}

@Composable
private fun BrowseGrid(onPick: (String) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        genreTiles.chunked(2).forEach { row ->
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                row.forEach { genre ->
                    val shape = RoundedCornerShape(16.dp)
                    Surface(
                        modifier = Modifier
                            .weight(1f)
                            .height(92.dp)
                            .elevatedCard(shape, 6.dp)
                            .clip(shape)
                            .clickable { onPick(genre.label) },
                        shape = shape,
                        color = Color.Transparent
                    ) {
                        Box(Modifier.fillMaxSize().background(Brush.linearGradient(genre.gradient))) {
                            Box(
                                Modifier.matchParentSize().background(
                                    Brush.verticalGradient(listOf(Color.Transparent, Color.Black.copy(alpha = .30f)))
                                )
                            )
                            Icon(
                                Icons.Default.GraphicEq, null,
                                tint = Color.White.copy(alpha = .22f),
                                modifier = Modifier
                                    .align(Alignment.BottomEnd)
                                    .padding(6.dp)
                                    .size(40.dp)
                                    .rotate(18f)
                            )
                            Text(
                                genre.label,
                                Modifier.align(Alignment.BottomStart).padding(14.dp),
                                color = WARM_WHITE,
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = (-.2).sp
                            )
                        }
                    }
                }
                if (row.size == 1) Spacer(Modifier.weight(1f))
            }
        }
    }
}

@Composable
private fun ArtworkImage(track: Track, tint: Color, onTint: (Color) -> Unit, modifier: Modifier) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val request = remember(track.artwork) {
        ImageRequest.Builder(context).data(track.artwork).build()
    }
    Box(modifier.background(tint.copy(alpha = .12f))) {
        AsyncImage(
            model = request,
            contentDescription = track.title,
            modifier = Modifier.matchParentSize(),
            contentScale = ContentScale.Crop,
            onSuccess = { success ->
                val bitmap = runCatching { success.result.image.toBitmap() }.getOrNull() ?: return@AsyncImage
                Palette.from(bitmap).generate { palette ->
                    val swatch = palette?.vibrantSwatch
                        ?: palette?.lightVibrantSwatch
                        ?: palette?.mutedSwatch
                        ?: palette?.dominantSwatch
                    swatch?.rgb?.let { onTint(Color(it)) }
                }
            }
        )
        Box(
            Modifier.matchParentSize().background(
                Brush.verticalGradient(listOf(Color.Transparent, tint.copy(alpha = .1f), BG.copy(alpha = .58f)))
            )
        )
    }
}

@Composable
private fun ArtworkImageUrl(url: String?, description: String?, tint: Color, onTint: (Color) -> Unit, modifier: Modifier) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val request = remember(url) {
        ImageRequest.Builder(context).data(url).build()
    }
    Box(modifier.background(tint.copy(alpha = .12f))) {
        AsyncImage(
            model = request,
            contentDescription = description,
            modifier = Modifier.matchParentSize(),
            contentScale = ContentScale.Crop,
            onSuccess = { success ->
                val bitmap = runCatching { success.result.image.toBitmap() }.getOrNull() ?: return@AsyncImage
                Palette.from(bitmap).generate { palette ->
                    val swatch = palette?.vibrantSwatch
                        ?: palette?.lightVibrantSwatch
                        ?: palette?.mutedSwatch
                        ?: palette?.dominantSwatch
                    swatch?.rgb?.let { onTint(Color(it)) }
                }
            }
        )
        Box(
            Modifier.matchParentSize().background(
                Brush.verticalGradient(listOf(Color.Transparent, tint.copy(alpha = .1f), BG.copy(alpha = .58f)))
            )
        )
    }
}

@Composable
private fun GlassCard(shape: RoundedCornerShape, modifier: Modifier, content: @Composable ColumnScope.() -> Unit) {
    Surface(
        modifier = modifier.elevatedCard(shape, 5.dp),
        shape = shape,
        color = CARD,
        tonalElevation = 0.dp
    ) {
        Column(content = content)
    }
}

@Composable
private fun Pill(text: String, tint: Color) {
    Surface(
        shape = RoundedCornerShape(9.dp),
        color = tint.copy(alpha = .15f),
        border = androidx.compose.foundation.BorderStroke(1.dp, tint.copy(alpha = .36f))
    ) {
        Text(text, Modifier.padding(horizontal = 7.dp, vertical = 3.dp), color = WARM_WHITE, fontSize = 8.sp, fontWeight = FontWeight.Bold, letterSpacing = .55.sp)
    }
}

@Composable
private fun ErrorPill(message: String) {
    Surface(Modifier.fillMaxWidth(), RoundedCornerShape(16.dp), color = Color(0xFF3A2924).copy(alpha = .72f)) {
        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.Info, null, tint = ACCENT, modifier = Modifier.size(18.dp))
            Spacer(Modifier.width(8.dp))
            Text(message, color = WARM_WHITE, fontSize = 12.sp)
        }
    }
}

@Composable
private fun EmptyState(icon: androidx.compose.ui.graphics.vector.ImageVector, title: String, subtitle: String) {
    GlassCard(RoundedCornerShape(24.dp), Modifier.fillMaxWidth()) {
        Column(Modifier.fillMaxWidth().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(icon, null, tint = ACCENT, modifier = Modifier.size(36.dp))
            Spacer(Modifier.height(10.dp))
            Text(title, color = WARM_WHITE, fontSize = 17.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(4.dp))
            Text(subtitle, color = MUTED, fontSize = 13.sp)
        }
    }
}

@Composable
private fun SearchBar(value: String, onValueChange: (String) -> Unit, onSearch: () -> Unit, placeholder: String = "Search for songs, artists, albums…") {
    val shape = RoundedCornerShape(22.dp)
    Surface(
        Modifier.fillMaxWidth().elevatedCard(shape, 4.dp).clip(shape),
        shape,
        color = CARD_RAISED.copy(alpha = .92f),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color.White.copy(alpha = .10f))
    ) {
        Row(Modifier.padding(start = 14.dp, end = 7.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.Search, null, tint = MUTED, modifier = Modifier.size(21.dp))
            TextField(
                value = value,
                onValueChange = onValueChange,
                Modifier.weight(1f),
                singleLine = true,
                placeholder = { Text(placeholder, color = MUTED, fontSize = 15.sp) },
                colors = TextFieldDefaults.colors(
                    focusedContainerColor = Color.Transparent,
                    unfocusedContainerColor = Color.Transparent,
                    disabledContainerColor = Color.Transparent,
                    focusedIndicatorColor = Color.Transparent,
                    unfocusedIndicatorColor = Color.Transparent,
                    focusedTextColor = WARM_WHITE,
                    unfocusedTextColor = WARM_WHITE,
                    cursorColor = ACCENT
                )
            )
            IconButton(onClick = onSearch, enabled = value.isNotBlank()) {
                Icon(Icons.Default.ArrowForward, "Search", tint = if (value.isBlank()) MUTED else ACCENT)
            }
        }
    }
}

@Composable
private fun PlaybackModes(mode: PlaybackMode, onMode: (PlaybackMode) -> Unit) {
    Row(
        Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Mode("Native Audio", Icons.Default.Headphones, mode == PlaybackMode.NATIVE) { onMode(PlaybackMode.NATIVE) }
        Mode("Online", Icons.Default.Language, mode == PlaybackMode.ONLINE) { onMode(PlaybackMode.ONLINE) }
        Mode("Auto", Icons.Default.Tune, mode == PlaybackMode.AUTO) { onMode(PlaybackMode.AUTO) }
    }
}

@Composable
private fun Mode(label: String, icon: androidx.compose.ui.graphics.vector.ImageVector, selected: Boolean, onClick: () -> Unit) {
    val shape = RoundedCornerShape(18.dp)
    Surface(
        Modifier
            .let { if (selected) it.elevatedCard(shape, 4.dp) else it }
            .clip(shape)
            .clickable(onClick = onClick),
        shape,
        color = if (selected) ACCENT else CARD_RAISED.copy(alpha = .7f),
        border = if (selected) null else androidx.compose.foundation.BorderStroke(1.dp, Color.White.copy(alpha = .10f))
    ) {
        Row(Modifier.padding(horizontal = 16.dp, vertical = 11.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, null, tint = if (selected) BG else WARM_WHITE, modifier = Modifier.size(19.dp))
            Spacer(Modifier.width(8.dp))
            Text(label, color = if (selected) BG else WARM_WHITE, fontSize = 13.sp, fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium)
        }
    }
}

@Composable
private fun SectionHeader(title: String, subtitle: String) {
    Column {
        Text(title, color = WARM_WHITE, fontSize = 21.sp, fontWeight = FontWeight.Bold, letterSpacing = (-.4).sp)
        Spacer(Modifier.height(2.dp))
        Text(subtitle, color = MUTED, fontSize = 13.sp, lineHeight = 17.sp)
    }
}

@Composable
private fun SongTile(track: Track, modifier: Modifier, onClick: () -> Unit) {
    var tint by remember(track.artwork) { mutableStateOf(ACCENT) }
    GlassCard(RoundedCornerShape(20.dp), modifier.clickable(onClick = onClick)) {
        Column {
            ArtworkImage(track, tint, { tint = it }, Modifier.fillMaxWidth().aspectRatio(1f).clip(RoundedCornerShape(18.dp)))
            Column(Modifier.padding(10.dp)) {
                Text(track.title, color = WARM_WHITE, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
                Text(track.artist, color = MUTED, fontSize = 12.sp, maxLines = 1)
            }
        }
    }
}

@Composable
private fun HistoryTile(track: Track, onClick: () -> Unit) {
    Column(Modifier.width(108.dp).clickable(onClick = onClick)) {
        ArtworkImage(track, ACCENT, {}, Modifier.size(108.dp).clip(RoundedCornerShape(16.dp)))
        Spacer(Modifier.height(6.dp))
        Text(track.title, color = WARM_WHITE, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
        Text(track.artist, color = MUTED, fontSize = 11.sp, maxLines = 1)
    }
}

@Composable
private fun SongCard(
    track: Track,
    rank: Int? = null,
    saved: Boolean = false,
    onPlay: () -> Unit,
    onQueue: () -> Unit,
    onSave: () -> Unit,
    removeFromQueue: Boolean = false
) {
    var tint by remember(track.artwork) { mutableStateOf(ACCENT) }
    val shape = RoundedCornerShape(16.dp)
    Surface(
        modifier = Modifier.fillMaxWidth().elevatedCard(shape, 3.dp).clip(shape).clickable(onClick = onPlay),
        shape = shape,
        color = CARD.copy(alpha = .82f)
    ) {
        Row(Modifier.padding(horizontal = 12.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            rank?.let {
                Text(it.toString(), Modifier.width(22.dp), color = MUTED, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
            }
            ArtworkImage(track, tint, { tint = it }, Modifier.size(52.dp).elevatedCard(RoundedCornerShape(12.dp), 4.dp).clip(RoundedCornerShape(12.dp)))
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(track.title, color = WARM_WHITE, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
                    if (track.lyricVideo) {
                        Spacer(Modifier.width(6.dp))
                        Pill("LYRICS", tint)
                    }
                }
                Text(track.artist, color = MUTED, fontSize = 12.sp, maxLines = 1)
            }
            IconButton(onClick = onSave) {
                Icon(if (saved) Icons.Default.Favorite else Icons.Default.FavoriteBorder, "Save", tint = if (saved) ACCENT else MUTED, modifier = Modifier.size(19.dp))
            }
            IconButton(onClick = onQueue) {
                Icon(if (removeFromQueue) Icons.Default.RemoveCircleOutline else Icons.Default.AddCircleOutline, "Queue", tint = MUTED, modifier = Modifier.size(20.dp))
            }
        }
    }
}

@Composable
private fun QueueSheet(
    queue: List<Track>,
    currentId: String?,
    onPlay: (Track) -> Unit,
    onRemove: (Track) -> Unit,
    onClear: () -> Unit
) {
    Column(
        Modifier.fillMaxWidth().padding(horizontal = 20.dp).padding(bottom = 28.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("Queue", color = WARM_WHITE, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                Text(queue.size.toString() + " songs", color = MUTED, fontSize = 13.sp)
            }
            TextButton(onClick = onClear) { Text("Clear", color = ACCENT) }
        }
        queue.take(15).forEach { track ->
            SongCard(
                track = track,
                saved = currentId == track.id,
                onPlay = { onPlay(track) },
                onQueue = { onRemove(track) },
                onSave = {},
                removeFromQueue = true
            )
        }
    }
}

@Composable
private fun FullPlayer(
    track: Track,
    isPlaying: Boolean,
    mode: PlaybackMode,
    progress: PlaybackProgress,
    saved: Boolean,
    onToggle: () -> Unit,
    onPrevious: () -> Unit,
    onNext: () -> Unit,
    onSeek: (Long) -> Unit,
    onSave: () -> Unit,
    onQueue: () -> Unit,
    onClose: () -> Unit
) {
    val context = androidx.compose.ui.platform.LocalContext.current
    Column(Modifier.fillMaxWidth().padding(horizontal = 20.dp).padding(bottom = 30.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Row(Modifier.fillMaxWidth().padding(bottom = 18.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onClose) { Icon(Icons.Default.KeyboardArrowDown, "Close", tint = WARM_WHITE) }
            Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                Text("Now Playing", color = MUTED, fontSize = 13.sp, fontWeight = FontWeight.Medium)
            }
            IconButton(onClick = onQueue) { Icon(Icons.Default.MoreVert, "More", tint = WARM_WHITE) }
        }
        Box(
            Modifier
                .fillMaxWidth()
                .aspectRatio(1f)
                .elevatedCard(RoundedCornerShape(20.dp), 16.dp)
                .clip(RoundedCornerShape(20.dp))
                .background(WARM_WHITE)
                .padding(14.dp)
        ) {
            if (mode == PlaybackMode.ONLINE || mode == PlaybackMode.AUTO) {
                YouTubeEmbed(track.youtubeUrl ?: "", Modifier.fillMaxSize().clip(RoundedCornerShape(8.dp)))
            } else {
                ArtworkImage(track, ACCENT, {}, Modifier.fillMaxSize().clip(RoundedCornerShape(8.dp)))
            }
        }
        Spacer(Modifier.height(18.dp))
        Column(Modifier.fillMaxWidth()) {
            Text(track.title, color = WARM_WHITE, fontSize = 22.sp, fontWeight = FontWeight.Bold, maxLines = 2)
            Text(track.artist, color = MUTED, fontSize = 14.sp, maxLines = 1)
        }
        Spacer(Modifier.height(14.dp))
        if (mode != PlaybackMode.ONLINE && progress.durationMs > 0) {
            Slider(
                value = progress.positionMs.coerceIn(0, progress.durationMs).toFloat(),
                onValueChange = { onSeek(it.toLong()) },
                valueRange = 0f..progress.durationMs.toFloat(),
                colors = SliderDefaults.colors(activeTrackColor = ACCENT, inactiveTrackColor = Color.White.copy(alpha = .14f), thumbColor = WARM_WHITE)
            )
            Row(Modifier.fillMaxWidth()) {
                Text(formatTime(progress.positionMs), color = MUTED, fontSize = 11.sp)
                Spacer(Modifier.weight(1f))
                Text(formatTime(progress.durationMs), color = MUTED, fontSize = 11.sp)
            }
            Spacer(Modifier.height(10.dp))
        }
        if (track.lyricVideo) {
            Pill("LYRICS AVAILABLE", ACCENT)
            Spacer(Modifier.height(10.dp))
        }
        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onPrevious) { Icon(Icons.Default.SkipPrevious, "Previous", tint = WARM_WHITE, modifier = Modifier.size(34.dp)) }
            Spacer(Modifier.width(22.dp))
            FilledIconButton(
                onClick = onToggle,
                modifier = Modifier.size(72.dp),
                colors = IconButtonDefaults.filledIconButtonColors(containerColor = ACCENT, contentColor = BG)
            ) {
                Icon(if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow, "Play", modifier = Modifier.size(36.dp))
            }
            Spacer(Modifier.width(22.dp))
            IconButton(onClick = onNext) { Icon(Icons.Default.SkipNext, "Next", tint = WARM_WHITE, modifier = Modifier.size(34.dp)) }
        }
        Spacer(Modifier.height(22.dp))
        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = {
                runCatching {
                    val sendIntent = android.content.Intent().apply {
                        action = android.content.Intent.ACTION_SEND
                        putExtra(android.content.Intent.EXTRA_TEXT, track.title + " — " + track.artist)
                        type = "text/plain"
                    }
                    context.startActivity(android.content.Intent.createChooser(sendIntent, null))
                }
            }) {
                Icon(Icons.Default.Share, "Share", tint = WARM_WHITE, modifier = Modifier.size(22.dp))
            }
            IconButton(onClick = onSave) {
                Icon(
                    if (saved) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                    "Save",
                    tint = if (saved) ACCENT else WARM_WHITE,
                    modifier = Modifier.size(24.dp)
                )
            }
            IconButton(onClick = onQueue) {
                Icon(Icons.Default.QueueMusic, "Queue", tint = WARM_WHITE, modifier = Modifier.size(22.dp))
            }
        }
    }
}

@Composable
private fun YouTubeEmbed(url: String, modifier: Modifier) {
    AndroidView(
        modifier = modifier,
        factory = { context ->
            WebView(context).apply {
                settings.javaScriptEnabled = true
                settings.domStorageEnabled = true
                settings.mediaPlaybackRequiresUserGesture = false
                settings.mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
                setBackgroundColor(android.graphics.Color.BLACK)
            }
        },
        update = { webView ->
            val directId = Regex("[?&]v=([^&]+)").find(url)?.groupValues?.get(1)
                ?: Regex("youtu\\.be/([^?&/]+)").find(url)?.groupValues?.get(1)
            val target = if (!directId.isNullOrBlank()) {
                "https://www.youtube-nocookie.com/embed/" + directId + "?playsinline=1&autoplay=1&rel=0"
            } else {
                url.ifBlank { "https://www.youtube.com/" }
            }
            if (webView.url != target) webView.loadUrl(target)
        }
    )
}
